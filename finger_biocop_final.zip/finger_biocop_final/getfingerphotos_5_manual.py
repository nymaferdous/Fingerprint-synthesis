import os
from os.path import isfile, join
import random
import cv2

import networkx as nx
import thinplate as tps
import numpy as np
import matplotlib.pyplot as plt
from src.image_enhance import fingerphoto_enhance, fingerprint_enhance, iterative_fph_enhance
import skimage.morphology as morph
from src.gettermination import getTerminationBifurcation_thin, getTerminationBifurcation_thin_ph
import time
from scipy.spatial import Delaunay
from triangulared import *

random.seed(5)


def showlist(imgs):
    plt.figure(figsize=(10, 8))
    for i in range(len(imgs)):
        plt.subplot(1, len(imgs), i + 1)
        plt.imshow(imgs[i])
    plt.show()


def remove_repeated(sin, r=10):
    res_l = []
    sin_arr = np.array(sin)
    # print(sin_arr.shape) 10x3

    while (sin_arr.shape[0] > 1):
        source = sin_arr[0:1, 0:2]
        dist = sin_arr.copy()
        dist = dist[:, 0:2]

        source = np.repeat(source, dist.shape[0], axis=0)
        d = (source - dist) ** 2
        d = d.T
        d = d.sum(0)
        d[d < r ** 2] = 0
        d[d > 0] = 1
        d = 1 - d

        repeated = np.where(d == 1)[0]
        notrep = np.where(d == 0)[0]

        # print(dist.shape)
        c = sin_arr[repeated, 3]
        data = sin_arr[repeated, :]

        argm = np.argmin(c)

        # c = c.mean(0)
        c = data[argm, :]
        res_l.append(c)
        sin_arr = sin_arr[notrep, :]

    if sin_arr.shape[0] == 1:
        res_l.append([int(sin_arr[0, 0]), int(sin_arr[0, 1]), sin_arr[0, 2]])
    return np.array(res_l)


def warp_image_cv(img, c_src, c_dst, dshape=None):
    dshape = dshape or img.shape
    theta = tps.tps_theta_from_points(c_src, c_dst, reduced=True)
    grid = tps.tps_grid(theta, c_dst, dshape)
    mapx, mapy = tps.tps_grid_to_remap(grid, img.shape)
    return cv2.remap(img, mapx, mapy, cv2.INTER_CUBIC)


def resize_img(img, w=800):
    rows, cols = np.shape(img)
    aspect_ratio = np.double(rows) / np.double(cols)

    new_rows = w
    new_cols = new_rows / aspect_ratio

    img = cv2.resize(img, (np.int(new_cols), np.int(new_rows)))
    return img


root_dir = '/media/aldb2/M2/datasets/fingerprint/mantech3d/'
finger_dir = '/media/aldb2/M2/datasets/fingerprint/mantechl1touchprint/'

class_list = [f.name for f in os.scandir(root_dir) if f.is_dir()]

ad_list = []
for c in class_list:
    sessions = [f.name for f in os.scandir(root_dir + c) if f.is_dir()]
    for s in sessions:
        address = root_dir + c + '/' + s + '/raw'
        files = [f for f in os.listdir(address) if isfile(join(address, f))]
        for f in files:
            if f[-5] == '0':
                ad_list.append(address + '/' + f)

random.shuffle(ad_list)

core_l = []
delta_l = []
wrong_l = []
coords = []


# temp_dir = './template/core/'
# adlist = []
# for file in os.listdir(temp_dir):
#     if file.endswith(".npy"):
#         ad = temp_dir + file
#         adlist.append(ad)
# a = np.load(adlist[0])
#
# filter = a[16-3:16+3, 16-3:16+3]
# # filter = filter - filter.mean()
# filter = filter / np.linalg.norm(filter.reshape(-1), ord=2)
# print(filter)
# showlist([filter])
# print(filter.shape)


def poincare(orientation, mask, w_sz=2, thr=0.06):
    w_sz = int(w_sz / 2)
    edge_list = []
    for i in range(-w_sz, w_sz):
        edge_list.append((w_sz, i))
    for i in range(-w_sz, w_sz):
        edge_list.append((-i, w_sz))
    for i in range(-w_sz, w_sz):
        edge_list.append((-w_sz, -i))
    for i in range(-w_sz, w_sz):
        edge_list.append((i, -w_sz))

    edge_list.reverse()
    outmap = np.zeros_like(orientation)
    mask_er = morph.erosion(mask, np.ones([40, 40]))

    diff1 = orientation[1:, 1:] - orientation[1:, :-1]
    diff2 = orientation[1:, 1:] - orientation[:-1, 1:]
    diff = np.abs(diff1) + np.abs((diff2))
    diff = diff > 1
    diff = diff * mask_er[1:, 1:]
    diff = morph.dilation(diff, np.ones([2, 2]))
    # showlist([fphoto_img, orientation, diff])
    # exit()
    idx = np.where(diff > 0)
    # print(len(idx))
    # print(idx)
    # exit()

    sings = []
    for idxx in range(idx[0].shape[0]):
        i = idx[0][idxx]
        j = idx[1][idxx]

        if i > 10 and j > 10 and i < fphoto_img.shape[0] - 10 and j < fphoto_img.shape[1] - 10:
            dat = orientation[i - 3:i + 3, j - 3:j + 3]
            dat = dat / np.linalg.norm(dat.reshape(-1), ord=2)

            outmap[i, j] = (dat * filter).sum()

    showlist([fphoto_img, fphoto_ori, outmap])
    # post processing

    # plt.subplot(1, 2, 1)
    # plt.imshow(mask)
    # plt.subplot(1, 2, 2)

    # plt.imshow(mask_er)
    # plt.show()
    outmap = outmap * mask_er
    # showlist([orientation, fphoto_img, outmap])

    #
    # t0 = time.time()
    #
    # for idxx in range(idx[0].shape[0]):
    #     i = idx[0][idxx]
    #     j = idx[1][idxx]
    #     o = outmap[i, j]
    #     print(i, j)
    #     crop = orientation[i - 4:i + 4, j - 4:j + 4]
    #     print(crop.shape)
    #     showlist([crop])
    #
    #
    #     if np.abs(o - 1) < thr:
    #         sings.append([i, j, 1, np.abs(o - 1)] + crop)
    #     elif np.abs(o - 0.5) < thr:
    #         sings.append([i, j, 2, np.abs(o - 0.5)] + crop)
    #     elif np.abs(o + 0.5) < thr:
    #         sings.append([i, j, 3, np.abs(o + 0.5)] + crop)
    sings = np.array(sings)

    # print(sings.shape)

    # remove repeated points and points on the edge

    sings = remove_repeated(sings, r=20)
    # sings = remove_onedge(sings, mask)

    # print(sings.shape)
    # exit()

    return sings


def compute_edge(xx):
    x = xx.copy()

    diff1 = x[1:, 1:] - x[1:, :-1]
    diff2 = x[1:, 1:] - x[:-1, 1:]
    diff = np.abs(diff1) + np.abs((diff2))
    diff = diff > 1
    diff = np.pad(diff, (1, 1), 'constant', constant_values=0)
    diff = diff[:-1, :-1]
    return diff.astype(np.bool)


def detect_core(edge, ratio_threshold=3):
    # select vertical lines
    lbl, lbl_n = morph.label(edge, return_num=True)
    cores = []
    for i in range(lbl_n):
        idx = np.where(lbl == i)
        y = idx[0]
        x = idx[1]
        if edge[y[0], x[0]]:  # check for bg
            h = y.max() - y.min()
            w = x.max() - x.min()
            ratio = h / w
            if ratio > ratio_threshold and y.max() < edge.shape[0] / 2:
                # plt.imshow(fph_lbl == i)
                core_y = y.max()
                idx = y.argmax()
                core_x = x[idx]
                cores.append([core_y, core_x])
    return cores


def geo_features(p0, p1):
    theta = (p0[0] - p1[0]) / (p0[1] - p1[1])
    theta = -1 * np.rad2deg(np.arctan(theta))

    d = np.linalg.norm(p0 - p1, ord=2)

    c = (p0 + p1) * 0.5
    return c, d, theta


for ai in range(0, len(ad_list)):
    add = ad_list[ai]
    add_finger = finger_dir + add[-47:-4]

    # print(add_finger)
    add_finger = add_finger.replace('raw/', '')
    add_finger = add_finger.replace('SI-', '')
    add_finger = add_finger[:-10] + '_' + add[-39] + '_' + add[-9] + '.png'
    print(add)
    print(add_finger)
    # exit()

    # print(ai, add)
    fphoto = cv2.imread(add)
    fprint = cv2.imread(add_finger)

    if (len(fphoto.shape) > 2):
        fphoto = cv2.cvtColor(fphoto, cv2.COLOR_BGR2GRAY)

    if (len(fprint.shape) > 2):
        fprint = cv2.cvtColor(fprint, cv2.COLOR_BGR2GRAY)
    fprint = cv2.flip(fprint, 1)

    w, h = fphoto.shape
    fphoto = resize_img(fphoto)
    # rotate the image
    angle90 = 90
    center = (w / 2, h / 2)
    fphoto = cv2.rotate(fphoto, cv2.ROTATE_90_CLOCKWISE)
    # hist eq
    clahe = cv2.createCLAHE(clipLimit=1.0, tileGridSize=(32, 32))
    fphoto = clahe.apply(fphoto)

    # plt.imshow(fphoto)
    # plt.show()

    # fprint = clahe.apply(fprint)
    a = fingerphoto_enhance(fphoto, fullreturn=True, filter=False)

    if a != -1:
        fph_ori = a[0]
        fph_mask = a[1]
        fph_img = a[2]
        fph_medfreq = a[3]

        print("fph med freq:", fph_medfreq)

        fpr_ori, fpr_mask, fpr_img = fingerprint_enhance(fprint, fullreturn=True, filter=False)

        fpr_mask_er = morph.erosion(fpr_mask, np.ones([40, 40]))
        fph_mask_er = morph.erosion(fph_mask, np.ones([40, 40]))

        # extract edges
        fpr_edge = compute_edge(fpr_ori) * fpr_mask_er
        fph_edge = compute_edge(fph_ori) * fph_mask_er

        fpr_edge_er = morph.dilation(fpr_edge, np.ones([3, 3]))
        fpr_edge1 = morph.remove_small_objects(fpr_edge_er, 400)

        fph_edge_er = morph.dilation(fph_edge, np.ones([3, 3]))
        fph_edge1 = morph.remove_small_objects(fph_edge_er.astype(np.bool), 400)

        fph_cores = detect_core(fph_edge1)
        print(fph_cores)
        fpr_cores = detect_core(fpr_edge1)
        print(fpr_cores)
        print(len(fpr_cores))
        if len(fph_cores) == 1 and len(fpr_cores) == 1:
            fph_cores = fph_cores[0]
            fpr_cores = fpr_cores[0]

            fpr_w = 300
            fpr_w = min(fpr_w, 2 * fpr_cores[1], 2 * (fpr_img.shape[1] - fpr_cores[1]))
            fpr_w = min(fpr_w, 2 * fpr_cores[0], 2 * (fpr_img.shape[0] - fpr_cores[0]))
            fph_w = 400
            fph_w = min(fph_w, 2 * fph_cores[1], 2 * (fph_img.shape[1] - fph_cores[1]))
            fph_w = min(fph_w, 2 * fph_cores[0], 2 * (fph_img.shape[0] - fph_cores[0]))

            # crop roi
            fpr_img = fpr_img[fpr_cores[0] - fpr_w // 2: fpr_cores[0] + fpr_w // 2,
                      fpr_cores[1] - fpr_w // 2: fpr_cores[1] + fpr_w // 2]

            fph_img = fph_img[fph_cores[0] - fph_w // 2: fph_cores[0] + int(1 * fph_w // 2),
                      fph_cores[1] - fph_w // 2: fph_cores[1] + fph_w // 2]

            fph_mask = fph_mask[fph_cores[0] - fph_w // 2: fph_cores[0] + int(1 * fph_w // 2),
                       fph_cores[1] - fph_w // 2: fph_cores[1] + fph_w // 2]

            # maske paches the same size
            fpr_img = resize_img(fpr_img, fph_w)

            fpr_bin, fpr_ori, fpr_mask, fpr_freq = fingerprint_enhance(fpr_img, fullreturn=True, filter=True)
            fpr_mask = morph.convex_hull_image(fpr_bin)

            med_freq = np.median(fpr_freq)
            if med_freq == 0:
                med_freq = 0.1
            # fph_bin, fph_ori, _ = fingerphoto_enhance(255 - fph_img, fullreturn=True, filter=True,
            #                                           rotation_correction=False, roi_selection=False, freq_in=med_freq)

            fph_bin = iterative_fph_enhance(fph_img)

            # showlist([fph_bin, fph_bin2])

            # extract minutiae

            # fpr_bin_inv = (1 - fpr_bin) * fpr_mask

            fpr_t_idx, fpr_b_idx = getTerminationBifurcation_thin(fpr_bin)
            # fpr_t_idx2, fpr_b_idx2 = getTerminationBifurcation_thin(fpr_bin_inv)

            fph_t_idx, fph_b_idx = getTerminationBifurcation_thin(fph_bin)
            # fph_t_idx = np.where(fph_t>0)
            # fph_b_idx = np.where(fph_b>0)

            # print(term_idx)
            # print(len(term_idx))
            # print(term_idx[0].shape)
            # exit()

            # fph_img = (1-fph_img) * fph_mask

            # plt.subplot(2, 3, 1)
            # plt.imshow(fpr_bin)
            # plt.scatter(fpr_t_idx[:, 1], fpr_t_idx[:, 0], marker='x', c = 'r')
            # plt.scatter(fpr_b_idx[:, 1], fpr_b_idx[:, 0], marker='x', c = 'b')
            #
            # plt.subplot(2, 3, 2)
            # plt.imshow(fpr_ori)
            # plt.subplot(2, 3, 3)
            # plt.imshow(fpr_img, cmap='gray')
            #
            # plt.subplot(2, 3, 4)
            # plt.imshow(fph_bin)
            # plt.scatter(fph_t_idx[:, 1], fph_t_idx[:, 0], marker='x', c = 'r')
            # plt.scatter(fph_b_idx[:, 1], fph_b_idx[:, 0], marker='x', c = 'b')
            # plt.subplot(2, 3, 5)
            # plt.imshow(fph_ori)
            # plt.subplot(2, 3, 6)
            # plt.imshow(fph_img, cmap='gray')
            # plt.show()

            # all points in the fingerprint
            fpr_points = np.concatenate((fpr_t_idx, fpr_b_idx), 0)
            fpr_minutiae = np.concatenate((np.zeros([fpr_t_idx.shape[0]]), np.ones([fpr_b_idx.shape[0]])))

            fph_points = np.concatenate((fph_t_idx, fph_b_idx), 0)
            fph_minutiae = np.concatenate((np.zeros([fph_t_idx.shape[0]]), np.ones([fph_b_idx.shape[0]])))

            l_fpr = []
            l_fph = []

            fig = plt.figure()
            ax1 = fig.add_subplot(121)
            ax1.imshow(fpr_img)
            ax1.scatter(fpr_points[:, 1], fpr_points[:, 0], marker='o', s=80, facecolors='none', edgecolors='k')
            ax2 = fig.add_subplot(122)
            ax2.imshow(fph_img)
            ax2.scatter(fph_points[:, 1], fph_points[:, 0], marker='o', s=80, facecolors='none', edgecolors='k')


            def onclick(event):
                global ix, iy
                ix, iy = event.xdata, event.ydata

                print('x = %d, y = %d' % (
                    ix, iy), event.button)  # 1=click, 3=dclick

                global l_fpr
                global l_fph

                if event.button == 1:  # select the point
                    if event.inaxes == ax1 and len(l_fpr) == len(l_fph):
                        l_fpr.append((ix, iy))
                        ax1.plot(ix, iy, 'rx', markersize=15)
                        fig.canvas.draw()
                    elif event.inaxes == ax2 and len(l_fph) == (len(l_fpr) - 1):
                        l_fph.append((ix, iy))
                        ax2.plot(ix, iy, 'rx', markersize=15)
                        fig.canvas.draw()
                elif event.button == 3:  # remove the point
                    if event.inaxes == ax1:
                        for ip in range(len(l_fpr)):
                            p = l_fpr[ip]
                            d = (p[0] - ix) ** 2 + (p[1] - iy) ** 2
                            print(d)
                            if d < 100:
                                del l_fpr[ip]
                                if len(l_fph) - 1 >= ip:
                                    del l_fph[ip]

                                ax1.cla()
                                ax2.cla()

                                ax1.imshow(fpr_img)

                                ax1.scatter(fpr_points[:, 1], fpr_points[:, 0], marker='o', s=80, facecolors='none',
                                            edgecolors='k')
                                for pp in l_fpr:
                                    ax1.plot(pp[0], pp[1], 'rx', markersize=15)

                                ax2.imshow(fph_img)
                                ax2.scatter(fph_points[:, 1], fph_points[:, 0], marker='o', s=80, facecolors='none',
                                            edgecolors='k')
                                for pp in l_fph:
                                    ax2.plot(pp[0], pp[1], 'rx', markersize=15)

                                fig.canvas.draw()
                    else:
                        plt.close(fig)

                return coords


            cid = fig.canvas.mpl_connect('button_press_event', onclick)
            mng = plt.get_current_fig_manager()
            # mng.resize(*mng.window.maxsize())
            plt.show()

            #
            if len(l_fpr)>0:
                target_points = np.array(l_fpr)
                source_points = np.array(l_fph)

                source_points = source_points / 400
                target_points = target_points / 400

                warped = warp_image_cv(fph_img, source_points, target_points, dshape=(512, 512))
                plt.subplot(1, 3, 1)
                plt.imshow(fph_img)
                plt.subplot(1, 3, 2)
                plt.imshow(warped)
                plt.subplot(1, 3, 3)
                plt.imshow(fpr_img)
                plt.show()
