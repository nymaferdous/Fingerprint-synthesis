import os
from os.path import isfile, join
import random
import cv2

import networkx as nx
import thinplate as tps
import numpy as np
import matplotlib.pyplot as plt
from src.image_enhance import fingerphoto_enhance, fingerprint_enhance, iterative_fph_enhance
import skimage.morphology as morph
from src.gettermination import getTerminationBifurcation_thin, getTerminationBifurcation_thin_ph
import time
from scipy.spatial import Delaunay
from triangulared import *

random.seed(5)


def showlist(imgs):
    plt.figure(figsize=(10, 8))
    for i in range(len(imgs)):
        plt.subplot(1, len(imgs), i + 1)
        plt.imshow(imgs[i])
    plt.show()


def remove_repeated(sin, r=10):
    res_l = []
    sin_arr = np.array(sin)
    # print(sin_arr.shape) 10x3

    while (sin_arr.shape[0] > 1):
        source = sin_arr[0:1, 0:2]
        dist = sin_arr.copy()
        dist = dist[:, 0:2]

        source = np.repeat(source, dist.shape[0], axis=0)
        d = (source - dist) ** 2
        d = d.T
        d = d.sum(0)
        d[d < r ** 2] = 0
        d[d > 0] = 1
        d = 1 - d

        repeated = np.where(d == 1)[0]
        notrep = np.where(d == 0)[0]

        # print(dist.shape)
        c = sin_arr[repeated, 3]
        data = sin_arr[repeated, :]

        argm = np.argmin(c)

        # c = c.mean(0)
        c = data[argm, :]
        res_l.append(c)
        sin_arr = sin_arr[notrep, :]

    if sin_arr.shape[0] == 1:
        res_l.append([int(sin_arr[0, 0]), int(sin_arr[0, 1]), sin_arr[0, 2]])
    return np.array(res_l)


def warp_image_cv(img, c_src, c_dst, dshape=None):
    dshape = dshape or img.shape
    theta = tps.tps_theta_from_points(c_src, c_dst, reduced=True)
    grid = tps.tps_grid(theta, c_dst, dshape)
    mapx, mapy = tps.tps_grid_to_remap(grid, img.shape)
    return cv2.remap(img, mapx, mapy, cv2.INTER_CUBIC)


def resize_img(img, w=800):
    rows, cols = np.shape(img)
    aspect_ratio = np.double(rows) / np.double(cols)

    new_rows = w
    new_cols = new_rows / aspect_ratio

    img = cv2.resize(img, (np.int(new_cols), np.int(new_rows)))
    return img


fph_dir = '/media/aldb2/0274E2F866ED37FC/BioCop fingerphoto/BioCop 2012/Cropped/'
fpr_dir = '/media/aldb2/0274E2F866ED37FC/BioCop fingerphoto/BioCop 2012/Fingerprint/'

class_list = [f.name for f in os.scandir(fph_dir) if f.is_dir()]

ad_list = []


def get_finger_info(s):
    1


for c in class_list:
    address = fph_dir + c + '/far/'
    files = [f for f in os.listdir(address) if isfile(join(address, f))]
    for f in files:
        fph_address = address + f
        p = f.split('_')

        if 'index' in f:
            a = 2
        elif 'middle' in f:
            a = 3
        elif 'ring' in f:
            a = 4
        else:
            exit('!!!!!!!!!')

        if 'left' in f:
            a = a + 5

        fpr_address = fpr_dir + c + '/' + p[1] + '/CrossMatch Verifier 300LC/1/' + c + '_' + p[1] + '_' + str(
            a) + '_001' + '_CrossMatchVerifier300LC.bmp'

        ad_list.append([fph_address, fpr_address])

random.shuffle(ad_list)

core_l = []
delta_l = []
wrong_l = []
coords = []





def compute_edge(xx):
    x = xx.copy()

    diff1 = x[1:, 1:] - x[1:, :-1]
    diff2 = x[1:, 1:] - x[:-1, 1:]
    diff = np.abs(diff1) + np.abs((diff2))
    diff = diff > 1
    diff = np.pad(diff, (1, 1), 'constant', constant_values=0)
    diff = diff[:-1, :-1]
    return diff.astype(np.bool)


def detect_core(edge, ratio_threshold=3):
    lbl, lbl_n = morph.label(edge, return_num=True, background=0)
    cores = []
    # print(lbl_n, "<<<<")
    for i in range(1, lbl_n + 1):
        idx = np.where(lbl == i)
        y = idx[0]
        x = idx[1]
        h = y.max() - y.min()
        w = x.max() - x.min()
        ratio = h / w
        # print(ratio)
        if ratio > ratio_threshold and y.max() < edge.shape[0] * 2 / 3:
            core_y = y.max()
            idx = y.argmax()
            core_x = x[idx]
            cores.append([core_y, core_x])
    # plt.imshow(edge)
    # for c in cores:
    #     plt.plot(c[1], c[0], '-or')
    # plt.show()
    return cores


def plot_list(l):
    for i in range(len(l)):
        plt.subplot(1, len(l), i + 1)
        plt.imshow(l[i])
    plt.show()


def geo_features(p0, p1):
    theta = (p0[0] - p1[0]) / (p0[1] - p1[1])
    theta = -1 * np.rad2deg(np.arctan(theta))

    d = np.linalg.norm(p0 - p1, ord=2)

    c = (p0 + p1) * 0.5
    return c, d, theta


def skin_detector(img):
    lower = np.array([0, 100, 80], dtype="uint8")  # [0, 48, 80]
    upper = np.array([20, 255, 255], dtype="uint8")
    converted = cv2.cvtColor(fphoto, cv2.COLOR_RGB2HSV)
    mask = cv2.inRange(converted, lower, upper)
    mask = morph.convex_hull_object(mask)
    mask = morph.remove_small_objects(mask, 2000)
    skinMask = mask.reshape(list(mask.shape) + [1])
    img_res = img * (skinMask > 0)

    return skinMask, np.uint8(img_res)


for ai in range(0, len(ad_list)):
    fph_ad = ad_list[ai][0]
    fpr_ad = ad_list[ai][1]

    # print(ai, add)
    fphoto = cv2.imread(fph_ad)
    fprint = cv2.imread(fpr_ad)



    if (len(fprint.shape) > 2):
        fprint = cv2.cvtColor(fprint, cv2.COLOR_BGR2GRAY)
    fprint = cv2.flip(fprint, 1)

    w, h, _ = fphoto.shape

    # get skin region

    fphoto = cv2.cvtColor(fphoto, cv2.COLOR_BGR2RGB)


    _, fphoto = skin_detector(fphoto)


    # convert to grayscale
    if (len(fphoto.shape) > 2):
        fphoto = cv2.cvtColor(fphoto, cv2.COLOR_RGB2GRAY)



    # hist eq
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(16, 16))
    fphoto = clahe.apply(fphoto)


    a = fingerphoto_enhance(fphoto, fullreturn=True, filter=False)



    if a != -1:
        fph_ori = a[0]
        fph_mask = a[1]
        fph_img = a[2]
        fph_medfreq = a[3]
        fph_rel = a[4]

        print("fph med freq:", fph_medfreq)

        fpr_ori, fpr_mask, fpr_img, fpr_rel = fingerprint_enhance(fprint, fullreturn=True, filter=False)

        # plot_list([fpr_img, fpr_ori, fpr_mask])

        fpr_mask_er = morph.erosion(fpr_mask, np.ones([40, 40]))
        fph_mask_er = morph.erosion(fph_mask, np.ones([40, 40]))

        # extract edges
        fpr_edge = compute_edge(fpr_ori) * fpr_mask_er
        fph_edge = compute_edge(fph_ori) * fph_mask_er

        fpr_edge_er = morph.dilation(fpr_edge, np.ones([3, 3]))
        fpr_edge1 = morph.remove_small_objects(fpr_edge_er, 400)

        fph_edge_er = morph.dilation(fph_edge, np.ones([3, 3]))
        fph_edge1 = morph.remove_small_objects(fph_edge_er.astype(np.bool), 400)

        fph_cores = detect_core(fph_edge1)
        fpr_cores = detect_core(fpr_edge1)

        print(len(fpr_cores), len(fph_cores))

        if len(fph_cores) == 1 and len(fpr_cores) == 1:
            fph_cores = fph_cores[0]
            fpr_cores = fpr_cores[0]
            plt.imshow(fph_img, cmap='gray')
            plt.plot(fph_cores[1], fph_cores[0], '-or', markersize=10)
            plt.show()

            fpr_w = 300
            fpr_w = min(fpr_w, 2 * fpr_cores[1], 2 * (fpr_img.shape[1] - fpr_cores[1]))
            fpr_w = min(fpr_w, 2 * fpr_cores[0], 2 * (fpr_img.shape[0] - fpr_cores[0]))
            fph_w = 340
            fph_w = min(fph_w, 2 * fph_cores[1], 2 * (fph_img.shape[1] - fph_cores[1]))
            fph_w = min(fph_w, 2 * fph_cores[0], 2 * (fph_img.shape[0] - fph_cores[0]))

            # crop roi
            fpr_img = fpr_img[fpr_cores[0] - fpr_w // 2: fpr_cores[0] + fpr_w // 2,
                      fpr_cores[1] - fpr_w // 2: fpr_cores[1] + fpr_w // 2]

            fph_img = fph_img[fph_cores[0] - fph_w // 2: fph_cores[0] + int(1 * fph_w // 2),
                      fph_cores[1] - fph_w // 2: fph_cores[1] + fph_w // 2]

            fph_mask = fph_mask[fph_cores[0] - fph_w // 2: fph_cores[0] + int(1 * fph_w // 2),
                       fph_cores[1] - fph_w // 2: fph_cores[1] + fph_w // 2]


            plt.imshow(fph_img, cmap='gray')
            plt.show()


            # maske paches the same size
            # fpr_img = resize_img(fpr_img, fph_w)

            pad_w = (fph_w - fpr_img.shape[0]) // 2

            print(pad_w)
            # fpr_img = np.pad(fpr_img, pad_width=(pad_w, pad_w), constant_values=(255,))

            # plot_list([fpr_img])

            fpr_bin, fpr_ori, fpr_mask, fpr_freq = fingerprint_enhance(fpr_img, fullreturn=True, filter=True,
                                                                       crop_roi=False)
            fpr_mask = morph.convex_hull_image(fpr_bin)

            med_freq = np.median(fpr_freq)
            if med_freq == 0:
                med_freq = 0.1
            # fph_bin, fph_ori, _ = fingerphoto_enhance(255 - fph_img, fullreturn=True, filter=True,
            #                                           rotation_correction=False, roi_selection=False, freq_in=med_freq)

            # fph_bin = iterative_fph_enhance(fph_img)

            fph_bin, _, fph_mask, _ = fingerprint_enhance(fph_img, fullreturn=True, filter=True,
                                                                       crop_roi=False)
            fph_bin = 1 - fph_bin
            fph_bin = fph_bin[20:-20, 20:-20]
            fph_mask = fph_mask[20:-20, 20:-20]
            print(fph_bin.shape)



            plot_list([fpr_bin, fph_bin, fph_mask])

            fpr_t_idx, fpr_b_idx = getTerminationBifurcation_thin(fpr_bin)
            fph_t_idx, fph_b_idx = getTerminationBifurcation_thin(fph_bin, isfingerphoto=True)


            # all points in the fingerprint
            fpr_points = np.concatenate((fpr_t_idx, fpr_b_idx), 0)
            fpr_minutiae = np.concatenate((np.zeros([fpr_t_idx.shape[0]]), np.ones([fpr_b_idx.shape[0]])))

            fph_points = np.concatenate((fph_t_idx, fph_b_idx), 0)
            fph_minutiae = np.concatenate((np.zeros([fph_t_idx.shape[0]]), np.ones([fph_b_idx.shape[0]])))

            tri_fpr = Delaunay(fpr_points)
            tri_fph = Delaunay(fph_points)

            n_sim_fpr = tri_fpr.simplices.shape[0]
            n_sim_fph = tri_fph.simplices.shape[0]

            corr_map = np.zeros([fpr_points.shape[0], fph_points.shape[0]])

            for i in range(n_sim_fpr):

                for i1 in range(3):

                    if i1 == 0:
                        idx_p0 = tri_fpr.simplices[i, 0]
                        idx_p1 = tri_fpr.simplices[i, 1]
                    elif i1 == 1:
                        idx_p0 = tri_fpr.simplices[i, 1]
                        idx_p1 = tri_fpr.simplices[i, 2]
                    elif i1 == 2:
                        idx_p0 = tri_fpr.simplices[i, 0]
                        idx_p1 = tri_fpr.simplices[i, 2]

                    # form a line
                    p0 = fpr_points[idx_p0, :]
                    p1 = fpr_points[idx_p1, :]
                    c_p, d_p, t_p = geo_features(p0, p1)

                    if (np.abs(t_p) <= 45 and p0[1] > p1[1]) or (np.abs(t_p) > 45 and p0[0] < p1[0]):
                        a = p0.copy()
                        p0 = p1.copy()
                        p1 = a.copy()

                        a = idx_p0.copy()
                        idx_p0 = idx_p1.copy()
                        idx_p1 = a.copy()

                    for j in range(n_sim_fph):

                        for j1 in range(3):

                            if j1 == 0:
                                idx_q0 = tri_fph.simplices[j, 0]
                                idx_q1 = tri_fph.simplices[j, 1]
                            elif j1 == 1:
                                idx_q0 = tri_fph.simplices[j, 1]
                                idx_q1 = tri_fph.simplices[j, 2]
                            elif j1 == 2:
                                idx_q0 = tri_fph.simplices[j, 0]
                                idx_q1 = tri_fph.simplices[j, 2]

                            # form a line
                            q0 = fph_points[idx_q0, :]
                            q1 = fph_points[idx_q1, :]

                            c_q, d_q, t_q = geo_features(q0, q1)

                            if (np.abs(t_q) <= 45 and q0[1] > q1[1]) or (np.abs(t_q) > 45 and q0[0] < q1[0]):
                                q2 = q0.copy()
                                q0 = q1.copy()
                                q1 = q2.copy()

                                a = idx_q0.copy()
                                idx_q0 = idx_q1.copy()
                                idx_q1 = a.copy()

                            mag_dif = np.abs(d_p - d_q)
                            mag_min = min(d_p, d_q)

                            cen_dif = np.linalg.norm(c_p - c_q, ord=2)

                            # if p0[1]<p1[0] and q0[1]<q1[1]

                            pq0_dif0 = np.linalg.norm(p0 - q0, ord=2)

                            ang_dif = np.abs(t_q - t_p)

                            if ang_dif > 90:
                                ang_dif = ang_dif - 90

                            if mag_dif < mag_min * 0.4 and cen_dif < 40 and ang_dif < 30:  # and (
                                # fpr_minutiae[idx_p0] == fph_minutiae[idx_q0]) and (
                                # fpr_minutiae[idx_p1] == fph_minutiae[idx_q1]):
                                print('tp:', t_p, ' tq:', t_q)
                                corr_map[idx_p0, idx_q0] += 1
                                corr_map[idx_p1, idx_q1] += 1

            img_tot = np.concatenate((fpr_bin, fph_bin), 0)

            plt.imshow(img_tot)

            corr_map_idx = np.argmax(corr_map, 1)
            corr_scores = corr_map.max(1)

            idx = np.argsort(corr_scores)[::-1]
            print(corr_scores[idx])
            best_idx = idx[0:10]

            # plt.scatter(fpr_t_idx[best_idx, 1], fpr_t_idx[best_idx, 0], marker='x', c='b')
            plt.scatter(fpr_points[best_idx, 1], fpr_points[best_idx, 0], marker='x', c='b')

            plt.scatter(fph_points[corr_map_idx[best_idx], 1], fph_points[corr_map_idx[best_idx], 0] + fpr_w, marker='x',
                        c='b')
            # plt.scatter(fph_b_idx[:, 1], fph_b_idx[:, 0] + 400, marker='x', c='b')
            for i in range(10):
                b = best_idx[i]
                # if corr_scores[b].max() > 12:
                # plt.plot([fpr_points[b, 1], fph_points[corr_map_idx[b], 1]],
                #              [fpr_points[b, 0], fph_points[corr_map_idx[b], 0] + 400], c='r')
                plt.text(fpr_points[b, 1], fpr_points[b, 0], str(i), color='r', size=24)
                plt.text(fph_points[corr_map_idx[b], 1], fph_points[corr_map_idx[b], 0] + fpr_w, str(i), color='r',
                         size=24)
                # plt.plot([fpr_points[b, 1], fph_points[corr_map_idx[b], 1]],
                #              [fpr_points[b, 0], fph_points[corr_map_idx[b], 0] + 400], c='r')

            plt.show()

            target_points = fpr_points[idx[0:10], :]
            source_points = fph_points[corr_map_idx[idx[0:10]], :]

            source_points = source_points / 400
            target_points = target_points / 400

            warped = warp_image_cv(fph_img, source_points, target_points, dshape=(512, 512))
            plt.subplot(1, 3, 1)
            plt.imshow(fph_img)
            plt.subplot(1, 3, 2)
            plt.imshow(warped)
            plt.subplot(1, 3, 3)
            plt.imshow(fpr_img)
            plt.show()

            # showlist([fpr_bin, fpr_ori, fpr_mask])

        #     plt.subplot(1, 2, 1)
        #     plt.imshow(fph_img)
        #     plt.scatter(fph_w//2, fph_w//2, c='r', marker='x')
        #
        #     plt.subplot(1, 2, 2)
        #     plt.imshow(fpr_img)
        #     plt.scatter(fpr_w//2, fpr_w//2, c='r', marker='x')
        #     plt.show()
        # # plt.scatter(core_x, core_y, c='r', marker='x')
        # plt.show()

        # showlist([fpr_img, fph_img, fpr_edge_er, fpr_edge1, fph_edge_er, fph_edge1])
