# -*- coding: utf-8 -*-
"""
Created on Mon Apr 18 22:50:30 2016

@author: utkarsh
"""
from src.ridge_segment import ridge_segment
from src.ridge_orient import ridge_orient
from src.ridge_freq import ridge_freq, ridge_freq2
from src.ridge_filter import ridge_filter
import skimage.morphology as morph
import skimage.measure as measure
import numpy as np
import matplotlib.pyplot as plt
import cv2
from scipy import ndimage, misc
import time


def showlist(imgs):
    for i in range(len(imgs)):
        plt.subplot(1, len(imgs), i + 1)
        plt.imshow(imgs[i])
    plt.show()


def rotate_image(image, angle, center=None):
    if center is None:
        center = tuple(np.array(image.shape[1::-1]) / 2)
    rot_mat = cv2.getRotationMatrix2D(center, angle, 1.0)
    result = cv2.warpAffine(image, rot_mat, image.shape[1::-1], flags=cv2.INTER_LINEAR)
    return result


def plot_list(l):
    for i in range(len(l)):
        plt.subplot(1, len(l), i + 1)
        plt.imshow(l[i])
    plt.show()


def fingerphoto_enhance(img, fullreturn=False, filter=True, rotation_correction=True, roi_selection=True, freq_in=None):
    blksze = 8  # 16
    thresh = 0.1
    normim, mask = ridge_segment(img, blksze, thresh)  # normalise the image and find a ROI

    # print(img.shape)


    mask = morph.remove_small_holes(mask, 6000)
    mask[0:5, :] = 0
    mask[:, 0:5] = 0
    mask[:, -5:] = 0
    mask[-5:, :] = 0
    mask = morph.convex_hull_object(mask)


    # get the biggest area
    if roi_selection:
        lbl, num = morph.label(mask, return_num=True)
        # get label of the finger

        lbl_finger = lbl[img.shape[0] // 2, img.shape[1] // 2]
        mask = (lbl == lbl_finger).astype(np.float)

        mask_sum = mask.sum(1)
        idx = np.where(mask_sum > 0)[0]
        top = idx[0]

        mask = mask[top:, ...]
        img = img[top:, ...]
        normim = normim[top:, ...]


    # correct the rotation of the fingerphoto

    # get center of mass along the horizontal axis

    width = img.shape[0]

    if rotation_correction:

        region_prop = measure.regionprops(np.uint8(mask))[0]
        theta = region_prop.orientation
        theta = np.rad2deg(theta)

        if theta < 0:
            theta = -90 - theta
        else:
            theta = 90 - theta
        # theta = -theta
        print("theta:", theta)

        # theta = theta / 2

        # showlist([img, mask])

        x = region_prop.centroid[1]
        y = region_prop.centroid[0]
        mask = rotate_image(mask, theta, center=(y, x))

        # plot_list([mask, mask1])

        img = rotate_image(img, theta, center=(y, x))
        normim, _ = ridge_segment(img, blksze, thresh)

        # plot_list([mask])

    # plot_list([normim, mask])

    gradientsigma = 1
    blocksigma = 7
    orientsmoothsigma = 7
    orientim, reliability = ridge_orient(normim, gradientsigma, blocksigma, orientsmoothsigma)  # find orientation of every pixel

    orientim = orientim * mask
    # plt.imshow(orientim)
    # plt.show()
    # exit()
    # plot_list([orientim, reliability*mask])

    if roi_selection:
        # extract top ROI from fingerphoto #########################################################
        mask_er = np.copy(mask)
        mask_er = morph.erosion(mask_er, np.ones([64, 64]))
        fph_ori_er = orientim * mask_er

        mask_sum = mask_er.sum(0)
        idx = np.where(mask_sum > 0)[0]
        x_0 = idx[0]
        idx = np.where(mask_sum[x_0 + 50:] == 0)[0]
        if len(idx) > 0:
            w_0 = idx[0] + 50
            x_0 -= int(0.05 * img.shape[1])
            x_1 = x_0 + w_0 + 2 * int(0.05 * img.shape[1])
        else:
            x_1 = img.shape[1] - x_0 - 1

        mask_sum = mask_er.sum(1)

        idx = np.where(mask_sum > 0)[0]
        y_0 = 0

        ori_sum = fph_ori_er.sum(1)
        # ori_sum[ori_sum == 0] = 10000

        mask_sum1 = mask_sum.copy()
        mask_sum1[mask_sum == 0] = 1
        ori_n = ori_sum / (mask_sum + 0.1)
        idx = np.where(ori_n[300:] < 0.75)[0]

        normim = normim[:, x_0:x_1, ...]
        img = img[:, x_0:x_1, ...]
        orientim = orientim[:, x_0:x_1, ...]
        mask = mask[:, x_0:x_1, ...]
        reliability = reliability[:, x_0:x_1, ...]

    # plot_list([img, normim, orientim])

    # showlist([normim, orientim, mask])

    #############################################################################################################
    blksze = 40  # 38
    windsze = 8  # 5
    minWaveLength = 3  # 5
    maxWaveLength = 15  # 15

    if freq_in is not None:
        freq = freq_in * mask
    else:
        freq, medfreq = ridge_freq(normim, mask, orientim, blksze, windsze, minWaveLength,
                                   maxWaveLength)  # find the overall frequency of ridges

        freq = medfreq * mask
    if filter:

        # freq = 0.11 * mask
        kx = 0.65
        ky = 0.65
        # exit()

        newim = ridge_filter(normim, orientim, freq, kx, ky)  # create gabor filter and do the actual filtering

        # th, bin_im = cv2.threshold(np.uint8(newim),0,255,cv2.THRESH_BINARY);

        newim = newim < 0

        if fullreturn:
            return newim, orientim * mask, mask, reliability
        return newim  # -3

    return orientim * mask, mask, img, medfreq, reliability


def image_enhance(img):
    blksze = 16  # 16
    thresh = 0.1
    # showlist([img])
    normim, mask = ridge_segment(img, blksze, thresh)  # normalise the image and find a ROI

    # mask = morph.convex_hull_object(mask)
    # mask = morph.remove_small_objects(mask, 500)

    # showlist([mask])
    # exit()

    gradientsigma = 1
    blocksigma = 7
    orientsmoothsigma = 7
    orientim = ridge_orient(normim, gradientsigma, blocksigma, orientsmoothsigma)  # find orientation of every pixel

    blksze = 16  # 36
    windsze = 5
    minWaveLength = 5  # 5
    maxWaveLength = 50  # 15
    freq, medfreq = ridge_freq(normim, mask, orientim, blksze, windsze, minWaveLength,
                               maxWaveLength)  # find the overall frequency of ridges
    if freq.max() > 0:

        freq = medfreq * mask
        kx = 0.65
        ky = 0.65
        newim = ridge_filter(normim, orientim, freq, kx, ky)  # create gabor filter and do the actual filtering

        # th, bin_im = cv2.threshold(np.uint8(newim),0,255,cv2.THRESH_BINARY);
        return (newim > 0)  # -3
    else:

        return np.zeros_like(normim).astype(np.uint8)


def fingerprint_enhance(img, fullreturn=False, filter=True, crop_roi=True):
    blksze = 16  # 16
    thresh = 0.1

    normim, mask = ridge_segment(img, blksze, thresh)  # normalise the image and find a ROI

    if crop_roi:
        lbl, num = morph.label(mask, return_num=True, background=0)

        max_s = 0
        best_lbl = 0
        for t in range(1, num):
            s = (lbl == t).sum()
            if s > max_s:
                max_s = s
                best_lbl = t
        mask = lbl == best_lbl
        mask = morph.convex_hull_object(mask)


        sy = mask.sum(1)
        idx = np.where(sy > 0)[0]
        y0 = idx[0]
        y1 = idx[-1]

        sx = mask.sum(0)
        idx = np.where(sx > 0)[0]
        x0 = idx[0]
        x1 = idx[-1]

        mask = mask[y0:y1, x0:x1]
        normim = normim[y0:y1, x0:x1]
        img = img[y0:y1, x0:x1]

    # plot_list([mask])

    # print("time for ridge segment:", time.time()-t0)

    gradientsigma = 1
    blocksigma = 7
    orientsmoothsigma = 7

    orientim, reliability = ridge_orient(normim, gradientsigma, blocksigma, orientsmoothsigma)  # find orientation of every pixel

    if filter:
        t0 = time.time()
        blksze = 38
        windsze = 5
        minWaveLength = 5  # 5
        maxWaveLength = 30  # 15
        freq, medfreq = ridge_freq(normim, mask, orientim, blksze, windsze, minWaveLength,
                                   maxWaveLength)  # find the overall frequency of ridges

        # print("time for ridge freq:", time.time()-t0)
        # print(medfreq, "XXXXXX")
        freq1 = medfreq * mask
        kx = 0.65
        ky = 0.65
        newim = ridge_filter(normim, orientim, freq1, kx, ky)  # create gabor filter and do the actual filtering

        # th, bin_im = cv2.threshold(np.uint8(newim),0,255,cv2.THRESH_BINARY);
        newim = newim < 0

        if fullreturn:
            return newim, orientim * mask, mask, freq, reliability
        return newim  # -3
    else:
        return orientim * mask, mask, img, reliability


def iterative_fph_enhance(img):
    # get the mask
    blksze = 10  # 16
    thresh = 0.1
    normim, mask = ridge_segment(img, blksze, thresh)  # normalise the image and find a ROI
    n_cols, n_rows = img.shape

    window_width = 128
    stride = 64
    offset = 14

    # stride = stride -2*offset

    n_x = int((n_cols - window_width) // stride + 2)
    n_y = int((n_rows - window_width) // stride + 2)

    print(n_x, n_y)

    output_ridge = np.zeros_like(img)
    mask_sum = np.ones_like(img)

    for i in range(n_x):
        print(i)
        for j in range(n_y):
            x = stride * i
            y = stride * j

            mask_block = mask[x:x + window_width, y:y + window_width]
            mask_mean = mask_block.mean()
            if mask_mean > 0.3:
                f_block = img[x:x + window_width, y:y + window_width]

                h0 = f_block.shape[0]
                w0 = f_block.shape[1]
                # plt.imshow(f_block)
                # plt.show()
                enhanced_img = image_enhance(f_block)
                # showlist([f_block, enhanced_img])
                # plt.subplot(1, 2, 1)
                # plt.imshow(f_block)
                # plt.subplot(1, 2, 2)
                # plt.imshow(f_block)
                # plt.imshow(enhanced_img, alpha=0.4)
                # plt.show()
                # for calculating the offset
                # idx = np.where(enhanced_img>0)
                # print(np.max(idx[0]))
                # print(np.min(idx[1]))
                # exit()

                output_ridge[x + offset:x + h0 - offset,
                y + offset:y + w0 - offset] += enhanced_img[offset:-offset, offset:-offset]
                mask_sum[x + offset:x + h0 - offset, y + offset:y + w0 - offset] += 1

                # output_ridge[]

                # plt.subplot(1, 2, 1)
                # plt.imshow(f_block, cmap='gray')
                # plt.subplot(1, 2, 2)
                # plt.imshow(f_block, cmap='gray')
                # plt.imshow(enhanced_img, cmap='jet', alpha=0.2)
                # plt.show()

    output_ridge = output_ridge / mask_sum

    output_ridge[output_ridge > 0] = 1
    # showlist([img, output_ridge, mask])
    return output_ridge
    # cv2.imwrite('../output/' + img_name, (255 * output_ridge))
    # plt.imshow(output_ridge/mask_sum, cmap='gray')
    # plt.show()
