# -*- coding: utf-8 -*-
"""
Created on Mon Apr 18 11:42:58 2016

@author: utkarsh
"""

import numpy as np
import cv2
import sys
import matplotlib.pyplot as plt

from src.image_enhance import image_enhance, fingerphoto_enhance

if __name__ == '__main__':

    print('loading sample image')
    img_name = '1.jpg'
    img = cv2.imread('../images/' + img_name)
    img = cv2.imread('/media/aldb2/M2/datasets/fingerprint/mantech3d/1021367/1/raw/SI-1021367_05172012_g20_1_1_0.pgm')

    h, w = img.shape[0:2]

    # rotate the image
    angle90 = 90
    center = (w / 2, h / 2)
    img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)

    # resize the image
    # d_width = 300
    # d_height = int((d_width / w) * h)
    # img = cv2.resize(img, (d_height, d_width), interpolation=cv2.INTER_AREA)

    # plt.imshow(img)
    # plt.show()
    # print(img.shape)
    # exit()
    img = img.astype(np.uint8)
    img = img[:, :, 0]

    # img_eq = cv2.equalizeHist(img)
    # create a CLAHE object (Arguments are optional).
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(16, 16))
    img_eq = clahe.apply(img)

    # plot the hist equalization results
    # plt.subplot(1, 2, 1)
    # plt.imshow(img, cmap='gray')
    # plt.subplot(1, 2, 2)
    # plt.imshow(img_eq, cmap='gray')
    # plt.show()
    # exit()
    img = np.copy(img_eq)




    rows, cols = np.shape(img)
    aspect_ratio = np.double(rows) / np.double(cols)

    new_rows = 800  # randomly selected number
    new_cols = new_rows / aspect_ratio

    img = cv2.resize(img, (np.int(new_cols), np.int(new_rows)))

    enhanced_img = fingerphoto_enhance(img)

    plt.subplot(1, 2, 1)
    plt.imshow(img, cmap='gray')
    plt.subplot(1, 2, 2)
    plt.imshow(enhanced_img, cmap='gray')
    plt.show()

    exit()
    print('saving the image')
    cv2.imwrite('../enhanced/' + img_name, (255 * enhanced_img))
