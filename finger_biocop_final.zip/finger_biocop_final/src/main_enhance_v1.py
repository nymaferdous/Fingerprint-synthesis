# -*- coding: utf-8 -*-
"""
Created on Mon Apr 18 11:42:58 2016

@author: utkarsh
"""

import numpy as np
import cv2
import sys
import matplotlib.pyplot as plt
from src.ridge_segment import ridge_segment
from src.image_enhance import image_enhance

if __name__ == '__main__':

    print('loading sample image')
    img_name = '1.jpg'
    img = cv2.imread('../images/' + img_name)
    img = cv2.imread('/media/aldb2/M2/datasets/fingerprint/mantech3d/1021367/1/raw/SI-1021367_05172012_g20_1_1_0.pgm')

    h, w = img.shape[0:2]

    # rotate the image
    angle90 = 90
    center = (w / 2, h / 2)
    img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
    if (len(img.shape) > 2):
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # img_eq = cv2.equalizeHist(img)
    # create a CLAHE object (Arguments are optional).
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(32, 32))
    img_eq = clahe.apply(img)
    img = np.copy(img_eq)

    # resize image
    rows, cols = np.shape(img)
    aspect_ratio = np.double(rows) / np.double(cols)

    new_rows = 800  # randomly selected number
    new_cols = new_rows / aspect_ratio

    img = cv2.resize(img, (np.int(new_cols), np.int(new_rows)))

    # get the mask
    blksze = 10  # 16
    thresh = 0.1
    normim, mask = ridge_segment(img, blksze, thresh)  # normalise the image and find a ROI

    #
    x_rand = 100
    y_rand = 200
    window_width = 192
    stride = 64

    n_x = int((new_cols - window_width) // stride + 1)
    n_y = int((new_rows - window_width) // stride + 1)

    print(n_x, n_y)

    output_ridge = np.zeros_like(img)
    mask_sum = np.ones_like(img)

    offset = 14
    for i in range(n_x):
        print(i)
        for j in range(n_y):
            x = stride * i
            y = stride * j

            mask_block = mask[x:x + window_width, y:y + window_width]
            mask_mean = mask_block.mean()
            if mask_mean > 0.3:
                f_block = img[x:x + window_width, y:y + window_width]

                # plt.imshow(f_block)
                # plt.show()
                enhanced_img = image_enhance(255 - f_block)
                # for calculating the offset
                #idx = np.where(enhanced_img>0)
                # print(np.max(idx[0]))
                # print(np.min(idx[1]))
                # exit()

                output_ridge[x+offset:x + window_width-offset, y+offset:y + window_width-offset] += enhanced_img[offset:-offset, offset:-offset]
                mask_sum[x+offset:x + window_width-offset, y+offset:y + window_width-offset] += 1




                # output_ridge[]

                # plt.subplot(1, 2, 1)
                # plt.imshow(f_block, cmap='gray')
                # plt.subplot(1, 2, 2)
                # plt.imshow(f_block, cmap='gray')
                # plt.imshow(enhanced_img, cmap='jet', alpha=0.2)
                # plt.show()

    output_ridge = output_ridge/mask_sum
    cv2.imwrite('../output/' + img_name, (255 * output_ridge))
    plt.imshow(output_ridge/mask_sum, cmap='gray')
    plt.show()
    # exit()
    # print('saving the image')

