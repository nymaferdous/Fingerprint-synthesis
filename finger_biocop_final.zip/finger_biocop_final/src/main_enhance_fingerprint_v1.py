# -*- coding: utf-8 -*-
"""
Created on Mon Apr 18 11:42:58 2016

@author: utkarsh
"""

import numpy as np
import cv2
import sys
import matplotlib.pyplot as plt
from src.ridge_segment import ridge_segment
from src.image_enhance import image_enhance, fingerprint_enhance

if __name__ == '__main__':

    print('loading sample image')
    img_name = 'fprint.jpg'
    img = cv2.imread('../images/' + img_name)
    img = cv2.imread('/home/aldb2/1021367_05172012_1_1.bmp')

    h, w = img.shape[0:2]

    img = cv2.flip(img, flipCode=1)
    if (len(img.shape) > 2):
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # img_eq = cv2.equalizeHist(img)
    # create a CLAHE object (Arguments are optional).
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(32, 32))
    img_eq = clahe.apply(img)
    img = np.copy(img_eq)

    # resize image
    rows, cols = np.shape(img)
    aspect_ratio = np.double(rows) / np.double(cols)

    new_rows = 400  # randomly selected number
    new_cols = new_rows / aspect_ratio

    img = cv2.resize(img, (np.int(new_cols), np.int(new_rows)))


    enhanced_img = fingerprint_enhance(img)

    # plt.imshow(enhanced_img, cmap='gray')
    # plt.show()
    # exit()

    cv2.imwrite('../output/' + img_name, (255 * enhanced_img))
    # plt.imshow(output_ridge/mask_sum, cmap='gray')
    # plt.show()
    # exit()
    # print('saving the image')

