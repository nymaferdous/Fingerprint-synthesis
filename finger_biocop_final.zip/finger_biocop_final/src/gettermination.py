import numpy as np
from skimage.morphology import convex_hull_image, erosion
from skimage.morphology import square
import skimage
import matplotlib.pyplot as plt
import copy


def showlist(imgs):
    plt.figure(figsize=(10, 8))
    for i in range(len(imgs)):
        plt.subplot(1, len(imgs), i + 1)
        plt.imshow(imgs[i])
    plt.show()


def getTerminationBifurcation(img, mask):
    img = img == 255
    (rows, cols) = img.shape
    minutiaeTerm = np.zeros(img.shape)
    minutiaeBif = np.zeros(img.shape)

    for i in range(1, rows - 1):
        for j in range(1, cols - 1):
            if (img[i][j] == 1):
                block = img[i - 1:i + 2, j - 1:j + 2]
                block_val = np.sum(block)
                if (block_val == 2):
                    minutiaeTerm[i, j] = 1
                elif (block_val == 4):
                    minutiaeBif[i, j] = 1

    # mask = convex_hull_image(mask > 0)
    # mask = erosion(mask, square(5))  # Structuing element for mask erosion = square(5)
    # minutiaeTerm = np.uint8(mask) * minutiaeTerm
    return (minutiaeTerm, minutiaeBif)


def remove_close_locations(x, dist_thsld=10):
    idx = copy.deepcopy(x)
    l = []
    while (idx.shape[1] > 0):
        v = idx[:, 0:1]
        v1 = np.repeat(v, idx.shape[1], 1)
        dist = np.linalg.norm(v1 - idx, ord=2, axis=0)
        ii = np.where(dist < dist_thsld)
        idx = np.delete(idx, ii, axis=1)
        l.append(v[:, 0])

    b_idx = np.array(l).T
    return b_idx


def remove_close_points(x, y, threshold=10):  # x, y: n x 2
    n_x = x.shape[0]
    n_y = y.shape[0]
    l_x = []
    l_y = []
    for i in range(n_x):
        v = x[i:i + 1, :]
        diff = y - v
        dist = np.linalg.norm(diff, ord=2, axis=1)
        dist = dist < threshold
        if dist.sum() == 0:
            l_x.append(v[0])

    for i in range(n_y):
        v = y[i:i + 1, :]
        diff = x - v
        dist = np.linalg.norm(diff, ord=2, axis=1)
        dist = dist < threshold
        if dist.sum() == 0:
            l_y.append(v[0])
    return np.array(l_x), np.array(l_y)


def remove_repeated_points(x, threshold=10):  # x, y: n x 2
    n_x = x.shape[0]
    l_x = []
    x1 = copy.deepcopy(x)
    while x1.shape[0] > 0:
        v = x1[0:1, :]
        diff = x1 - v
        dist = np.linalg.norm(diff, ord=2, axis=1)
        ii = np.where(dist < threshold)
        x1 = np.delete(x1, ii, axis=0)
        l_x.append(v[0])
        # print(x1.shape[0], "<<")
        # exit()
    return np.array(l_x)


def comp_minu(img):
    idx = np.where(img > 0)
    idx = np.array(idx)
    # print(idx.shape)  # 2 x n
    t_l = []
    b_l = []
    for i in range(idx.shape[1]):
        block = img[idx[0, i] - 1:idx[0, i] + 2, idx[1, i] - 1:idx[1, i] + 2]
        s = block.sum()
        if s == 2:
            t_l.append(idx[:, i])
        elif s == 4:
            b_l.append(idx[:, i])
    t_l = np.array(t_l)  # n x 2
    b_l = np.array(b_l)

    # remove spurious minutiae (small branches)
    if b_l.shape[0] > 0 and t_l.shape[0] > 0:
        b_l, t_l = remove_close_points(b_l, t_l, threshold=10)

    if b_l.shape[0] > 0:
        b_l = remove_repeated_points(b_l)

    return t_l, b_l


def getTerminationBifurcation_thin(img, isfingerphoto=False):
    # if isfingerphoto:
        # img = skimage.morphology.remove_small_objects(img > 0, min_size=100)
        # img = skimage.morphology.remove_small_holes(img > 0, min_size=100)

    lbl, n_obj = skimage.morphology.label(img, return_num=True, background=0)
    l_t = []
    l_b = []
    for i in range(1, n_obj):
        thined = skimage.morphology.skeletonize(lbl == i)
        t, b = comp_minu(thined)
        for p in range(t.shape[0]):
            l_t.append(t[p])

        for p in range(b.shape[0]):
            l_b.append(b[p])

    l_t = np.array(l_t)  # n x 2
    l_b = np.array(l_b)  # n x 2


    mask = skimage.morphology.convex_hull_image(img)
    mask[0:1, :] = 0
    mask[:, 0:1] = 0
    mask[-1:, :] = 0
    mask[:, -1:] = 0
    if isfingerphoto:
        mask = erosion(mask, square(10))  # Structuing element for mask erosion = square(5)
    else:
        mask = erosion(mask, square(10))

    # showlist([mask, mask1])
    # remove termination points on the edge
    img_t = np.zeros_like(img)
    for p in l_t:
        img_t[p[0], p[1]] = 1
    img_t = img_t * mask
    l_t = np.array(np.where(img_t > 0)).T

    img_b = np.zeros_like(img)
    for p in l_b:
        img_b[p[0], p[1]] = 1
    img_b = img_b * mask
    l_b = np.array(np.where(img_b > 0)).T

    # print('landmarks')
    # plt.imshow(img)
    # plt.scatter(l_t[:, 1], l_t[:, 0], c='r')
    # plt.scatter(l_b[:, 1], l_b[:, 0], c='b')
    # plt.show()

    # # showlist([mask])
    # (rows, cols) = img.shape
    # minutiaeTerm = np.zeros(img.shape)
    # minutiaeBif = np.zeros(img.shape)
    #
    # for i in range(1, rows - 1):
    #     for j in range(1, cols - 1):
    #         if (img[i][j] == 1):
    #             block = img[i - 1:i + 2, j - 1:j + 2]
    #             block_val = np.sum(block)
    #             if (block_val == 2):
    #                 minutiaeTerm[i, j] = 1
    #             elif (block_val == 4):
    #                 minutiaeBif[i, j] = 1

    # showlist([mask])

    # showlist([mask])

    # minutiaeTerm = mask * minutiaeTerm
    # # remove repeated minutiae
    # dist_thsld = 8
    # idx = np.where(minutiaeBif > 0)
    # idx = np.array(idx)  # 2 x n
    #
    # b_idx = remove_close_locations(idx)
    # t_idx = np.where(minutiaeTerm > 0)
    # t_idx = np.array(t_idx)
    # print(t_idx.shape)
    # t_idx = remove_close_locations(t_idx)
    # print(t_idx.shape)
    return (l_t, l_b)


def getTerminationBifurcation_thin_ph(img):
    img = skimage.morphology.remove_small_objects(img, min_size=200)
    img = skimage.morphology.remove_small_holes(img, min_size=200)
    img = skimage.morphology.skeletonize(img)
    mask = skimage.morphology.convex_hull_image(img)
    # showlist([mask])
    (rows, cols) = img.shape
    minutiaeTerm = np.zeros(img.shape)
    minutiaeBif = np.zeros(img.shape)

    for i in range(1, rows - 1):
        for j in range(1, cols - 1):
            if (img[i][j] == 1):
                block = img[i - 1:i + 2, j - 1:j + 2]
                block_val = np.sum(block)
                if (block_val == 2):
                    minutiaeTerm[i, j] = 1
                elif (block_val == 4):
                    minutiaeBif[i, j] = 1

    # showlist([mask])
    mask = erosion(mask, square(100))  # Structuing element for mask erosion = square(5)
    # showlist([mask])
    minutiaeTerm = mask * minutiaeTerm

    # remove repeated minutiae
    dist_thsld = 8
    idx = np.where(minutiaeBif > 0)
    idx = np.array(idx)  # 2 x n
    l = []
    while (idx.shape[1] > 0):
        v = idx[:, 0:1]
        v1 = np.repeat(v, idx.shape[1], 1)
        dist = np.linalg.norm(v1 - idx, ord=2, axis=0)
        ii = np.where(dist < dist_thsld)
        idx = np.delete(idx, ii, axis=1)
        l.append(v[:, 0])

    b_idx = np.array(l).T
    # b_idx = np.unique(l, axis=0)

    t_idx = np.where(minutiaeTerm > 0)

    return (t_idx, b_idx)
