import matplotlib.pyplot as plt

import numpy as np
import matplotlib.pyplot as plt

x = np.arange(-10, 10)
y = x ** 2

fig = plt.figure()
# plt.ion()
ax = fig.add_subplot(111)
ax.plot(x, y)

coords = []


def onclick(event):
    global ix, iy, ax
    ix, iy = event.xdata, event.ydata
    print('x = %d, y = %d' % (
        ix, iy), event.button)

    global coords
    coords.append((ix, iy))
    ax.plot(ix, iy, 'x')
    plt.draw()

    fig.canvas.draw()
    if len(coords) == 20:
        fig.canvas.mpl_disconnect(cid)

    return coords


cid = fig.canvas.mpl_connect('button_press_event', onclick)
mng = plt.get_current_fig_manager()
mng.resize(*mng.window.maxsize())
plt.show()