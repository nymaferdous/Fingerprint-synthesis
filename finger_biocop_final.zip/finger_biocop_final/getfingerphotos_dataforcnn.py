import os
from os.path import isfile, join
import random
import cv2
import numpy as np
import matplotlib.pyplot as plt
from src.image_enhance import fingerphoto_enhance
import skimage.morphology as morph
import time

random.seed(5)


def showlist(imgs):
    plt.figure(figsize=(10, 8))
    for i in range(len(imgs)):
        plt.subplot(1, len(imgs), i + 1)
        plt.imshow(imgs[i])
    plt.show()


def remove_repeated(sin, r=10):
    res_l = []
    sin_arr = np.array(sin)
    # print(sin_arr.shape) 10x3

    while (sin_arr.shape[0] > 1):
        source = sin_arr[0:1, 0:2]
        dist = sin_arr.copy()
        dist = dist[:, 0:2]

        source = np.repeat(source, dist.shape[0], axis=0)
        d = (source - dist) ** 2
        d = d.T
        d = d.sum(0)
        d[d < r ** 2] = 0
        d[d > 0] = 1
        d = 1 - d

        repeated = np.where(d == 1)[0]
        notrep = np.where(d == 0)[0]

        # print(dist.shape)
        c = sin_arr[repeated, 3]
        data = sin_arr[repeated, :]

        argm = np.argmin(c)

        # c = c.mean(0)
        c = data[argm, :]
        res_l.append(c)
        sin_arr = sin_arr[notrep, :]

    if sin_arr.shape[0] == 1:
        res_l.append([int(sin_arr[0, 0]), int(sin_arr[0, 1]), sin_arr[0, 2]])
    return np.array(res_l)


def resize_img(img, w=800):
    rows, cols = np.shape(img)
    aspect_ratio = np.double(rows) / np.double(cols)

    new_rows = w
    new_cols = new_rows / aspect_ratio

    img = cv2.resize(img, (np.int(new_cols), np.int(new_rows)))
    return img


root_dir = '/media/aldb2/M2/datasets/fingerprint/mantech3d/'

class_list = [f.name for f in os.scandir(root_dir) if f.is_dir()]

ad_list = []
for c in class_list:
    sessions = [f.name for f in os.scandir(root_dir + c) if f.is_dir()]
    for s in sessions:
        address = root_dir + c + '/' + s + '/raw/'
        files = [f for f in os.listdir(address) if isfile(join(address, f))]
        for f in files:
            if f[-5] == '0':
                ad_list.append(address + '/' + f)

random.shuffle(ad_list)

core_l = []
delta_l = []
wrong_l = []
coords = []


def poincare(orientation, mask, w_sz=2, thr=0.06):
    w_sz = int(w_sz / 2)
    edge_list = []
    for i in range(-w_sz, w_sz):
        edge_list.append((w_sz, i))
    for i in range(-w_sz, w_sz):
        edge_list.append((-i, w_sz))
    for i in range(-w_sz, w_sz):
        edge_list.append((-w_sz, -i))
    for i in range(-w_sz, w_sz):
        edge_list.append((i, -w_sz))

    edge_list.reverse()
    outmap = np.zeros_like(orientation)
    mask_er = morph.erosion(mask, np.ones([40, 40]))

    diff1 = orientation[1:, 1:] - orientation[1:, :-1]
    diff2 = orientation[1:, 1:] - orientation[:-1, 1:]
    diff = np.abs(diff1) + np.abs((diff2))
    diff = diff > 1
    diff = diff * mask_er[1:, 1:]
    diff = morph.dilation(diff, np.ones([2, 2]))
    # showlist([fphoto_img, orientation, diff])
    # exit()
    idx = np.where(diff > 0)
    # print(len(idx))
    # print(idx)
    # exit()

    sings = []
    for idxx in range(idx[0].shape[0]):
        i = idx[0][idxx]
        j = idx[1][idxx]

        if i > 10 and j > 10 and i < fphoto_img.shape[0] - 10 and j < fphoto_img.shape[1] - 10:
            dat = orientation[i - 3:i + 3, j - 3:j + 3]
            outmap[i, j] = (dat * filter).sum()

    showlist([fphoto_img, fphoto_ori, outmap])
    # post processing

    # plt.subplot(1, 2, 1)
    # plt.imshow(mask)
    # plt.subplot(1, 2, 2)

    # plt.imshow(mask_er)
    # plt.show()
    outmap = outmap * mask_er
    # showlist([orientation, fphoto_img, outmap])

    #
    # t0 = time.time()
    #
    # for idxx in range(idx[0].shape[0]):
    #     i = idx[0][idxx]
    #     j = idx[1][idxx]
    #     o = outmap[i, j]
    #     print(i, j)
    #     crop = orientation[i - 4:i + 4, j - 4:j + 4]
    #     print(crop.shape)
    #     showlist([crop])
    #
    #
    #     if np.abs(o - 1) < thr:
    #         sings.append([i, j, 1, np.abs(o - 1)] + crop)
    #     elif np.abs(o - 0.5) < thr:
    #         sings.append([i, j, 2, np.abs(o - 0.5)] + crop)
    #     elif np.abs(o + 0.5) < thr:
    #         sings.append([i, j, 3, np.abs(o + 0.5)] + crop)
    sings = np.array(sings)

    # print(sings.shape)

    # remove repeated points and points on the edge

    sings = remove_repeated(sings, r=20)
    # sings = remove_onedge(sings, mask)

    # print(sings.shape)
    # exit()

    return sings


counter = 0
for ai in range(0, len(ad_list)):
    add = ad_list[ai]
    print(ai, add)
    fphoto = cv2.imread(add)
    if (len(fphoto.shape) > 2):
        fphoto = cv2.cvtColor(fphoto, cv2.COLOR_BGR2GRAY)
    w, h = fphoto.shape
    fphoto = resize_img(fphoto)
    # rotate the image
    angle90 = 90
    center = (w / 2, h / 2)
    fphoto = cv2.rotate(fphoto, cv2.ROTATE_90_CLOCKWISE)
    # hist eq
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(32, 32))
    fphoto = clahe.apply(fphoto)

    a = fingerphoto_enhance(fphoto, fullreturn=True, filter=False)

    if a != -1:
        fphoto_ori = a[0]
        fphoto_mask = a[1]
        fphoto_img = a[2]

        # t0 = time.time()
        # sings = poincare(fphoto_ori, fphoto_mask)
        # print(time.time() - t0)
        # print(sings.shape)
        # exit()
        mask_er = morph.erosion(fphoto_mask, np.ones([40, 40]))
        f_ori_normal = fphoto_ori / np.pi
        f_ori_normal = np.clip(fphoto_ori, a_min=0, a_max=1)

        fig = plt.figure(figsize=(10, 20))
        plt.subplot(1, 2, 1)
        plt.imshow(fphoto_img)
        plt.subplot(1, 2, 2)
        plt.imshow(fphoto_ori)


        # plt.scatter(sings[:, 1], sings[:, 0], c='r', marker='x')
        def onclick(event):
            global ix, iy
            ix, iy = event.xdata, event.ydata

            ix = int(ix)
            iy = int(iy)

            # print('x = %d, y = %d' % (
            #     ix, iy))
            global coords
            global counter
            coords.append((ix, iy, event.button))
            crop = f_ori_normal[iy - 8:iy + 8, ix - 8:ix + 8]
            crop = np.uint8(crop * 255)
            # plt.imshow(crop)
            # plt.show()
            counter += 1
            if event.button == 1:
                plt.scatter(ix, iy, c='r', marker='^')
                cv2.imwrite('./data/core/' + str(counter) + '.png', crop)
            elif event.button == 3:
                plt.scatter(ix, iy, c='r', marker='v')
                cv2.imwrite('./data/delta/' + str(counter) + '.png', crop)

            fig.canvas.draw()

            # if len(coords) == 2:
            #     fig.canvas.mpl_disconnect(cid)


        cid = fig.canvas.mpl_connect('button_press_event', onclick)
        plt.show()

        print(coords)

        diff1 = fphoto_ori[1:, 1:] - fphoto_ori[1:, :-1]
        diff2 = fphoto_ori[1:, 1:] - fphoto_ori[:-1, 1:]
        diff = np.abs(diff1) + np.abs((diff2))
        diff = diff > 1
        diff = diff * mask_er[1:, 1:]
        # showlist([fphoto_img, orientation, diff])
        # exit()
        idx = np.where(diff > 0)

        cc = 0
        while (cc < 10) and (len(coords) > 0):
            rand = np.random.randint(0, idx[0].shape[0])
            y = idx[0][rand]
            x = idx[1][rand]

            n = len(coords)
            coord0 = np.array(coords)
            coord0 = coord0[:, 0:2]
            coord1 = np.array([y, x]).reshape(1, 2)
            coord1 = np.repeat(coord1, n, axis=0)
            dist = (coord0 - coord1) ** 2
            dist = dist.sum(1)
            if dist.max() > 100:
                crop = f_ori_normal[y - 8:y + 8, x - 8:x + 8]
                if crop.shape[0] == 16 and crop.shape[1] == 16:
                    crop = np.uint8(crop * 255)
                    counter += 1
                    cv2.imwrite('./data/bg/' + str(counter) + '.png', crop)
                    cc += 1

        coords = []
    else:
        exit("a==-1")

exit()
