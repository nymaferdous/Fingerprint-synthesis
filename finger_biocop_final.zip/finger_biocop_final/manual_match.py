import cv2
import numpy as np
import matplotlib.pyplot as plt
from src.image_enhance import fingerprint_enhance, fingerphoto_enhance

fprint = cv2.imread('/home/aldb2/Untitled Folder/1021367_05172012_1_1.bmp')
fphoto = cv2.imread('/home/aldb2/Untitled Folder/SI-1021367_05172012_g20_1_1_0.png')

if (len(fphoto.shape) > 2):
    fphoto = cv2.cvtColor(fphoto, cv2.COLOR_BGR2GRAY)
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(32, 32))
fphoto = clahe.apply(fphoto)
# img = np.copy(img_eq)

# fphoto[fphoto > 128] = 255
# fphoto[fphoto <= 128] = 0

plt.subplot(1, 2, 1)
plt.imshow(fprint)
plt.subplot(1, 2, 2)
plt.imshow(fphoto, cmap='gray')
plt.show()