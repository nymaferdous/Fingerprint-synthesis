import cv2
import numpy as np
import matplotlib.pyplot as plt
import time
from src.image_enhance import fingerphoto_enhance, fingerprint_enhance
import skimage.morphology as morph


def resize_img(img, w=800):
    rows, cols = np.shape(img)
    aspect_ratio = np.double(rows) / np.double(cols)

    new_rows = w
    new_cols = new_rows / aspect_ratio

    img = cv2.resize(img, (np.int(new_cols), np.int(new_rows)))
    return img


fprint = cv2.imread('/home/aldb2/Untitled Folder/1021367_05172012_1_1.bmp')
fphoto = cv2.imread('/home/aldb2/Untitled Folder/SI-1021367_05172012_g20_1_1_0.png')

if (len(fprint.shape) > 2):
    fprint = cv2.cvtColor(fprint, cv2.COLOR_BGR2GRAY)

if (len(fphoto.shape) > 2):
    fphoto = cv2.cvtColor(fphoto, cv2.COLOR_BGR2GRAY)

fprint = resize_img(fprint)
fphoto = resize_img(fphoto)

# hist eq
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(32, 32))
fphoto = clahe.apply(fphoto)

fprint = cv2.flip(fprint, 1)

# compute the ridge information
t0 = time.time()


def remove_repeated(sin, r=10):
    res_l = []
    sin_arr = np.array(sin)
    # print(sin_arr.shape) 10x3

    while (sin_arr.shape[0] > 1):
        source = sin_arr[0:1, 0:2]
        dist = sin_arr.copy()
        dist = dist[:, 0:2]

        source = np.repeat(source, dist.shape[0], axis=0)
        d = (source - dist) ** 2
        d = d.T
        d = d.sum(0)
        d[d < r ** 2] = 0
        d[d > 0] = 1
        d = 1 - d

        repeated = np.where(d == 1)[0]
        notrep = np.where(d == 0)[0]

        # print(dist.shape)
        c = sin_arr[repeated, 3]
        data = sin_arr[repeated, :]

        argm = np.argmin(c)

        #c = c.mean(0)
        c = data[argm, :]
        res_l.append(c)
        sin_arr = sin_arr[notrep, :]

    if sin_arr.shape[0] == 1:
        res_l.append([int(sin_arr[0, 0]), int(sin_arr[0, 1]), sin_arr[0, 2]])
    return np.array(res_l)


def remove_onedge(sins, mask, w_size=20):
    mask = mask.astype(np.float)
    w_size = int(w_size / 2)
    res_list = []
    for ip in range(sins.shape[0]):
        x = int(sins[ip, 0])
        y = int(sins[ip, 1])
        block = mask[x - w_size:x + w_size, y - w_size:y + w_size]
        if block.mean() > 0.5:
            res_list.append(sins[ip, :])
    return np.array(res_list)


def poincare(orientation, mask, w_sz=2, thr=0.1):
    w_sz = int(w_sz / 2)
    edge_list = []
    for i in range(-w_sz, w_sz):
        edge_list.append((w_sz, i))
    for i in range(-w_sz, w_sz):
        edge_list.append((-i, w_sz))
    for i in range(-w_sz, w_sz):
        edge_list.append((-w_sz, -i))
    for i in range(-w_sz, w_sz):
        edge_list.append((i, -w_sz))

    edge_list.reverse()
    outmap = np.zeros_like(orientation)
    for i in range(10, orientation.shape[0] - 10):
        for j in range(10, orientation.shape[1] - 10):
            delta = 0
            for ie in range(len(edge_list) - 1):
                e0 = edge_list[ie]
                e1 = edge_list[ie + 1]
                # print(e0, e1, "e0e1")
                d = orientation[i + e1[0], j + e1[1]] - orientation[i + e0[0], j + e0[1]]

                # print(d, 'd')

                if np.abs(d) < np.pi / 2:
                    delta = delta + d
                    # print("d1")
                elif d <= -np.pi / 2:
                    delta = delta + d + np.pi
                    # print("d2")
                else:  # d >= np.pi / 2:
                    delta = delta + np.pi - d
                    # print("d3")
                # input("dm")
            # print(delta)
            # delta = delta / (np.pi * 2)
            outmap[i, j] = delta
    # post processing

    # plt.subplot(1, 2, 1)
    # plt.imshow(mask)
    # plt.subplot(1, 2, 2)
    mask_er = morph.erosion(mask, np.ones([40, 40]))
    # plt.imshow(mask_er)
    # plt.show()
    outmap = outmap * mask_er

    sings = []

    t0 = time.time()

    for i in range(40, outmap.shape[0] - 40):
        for j in range(40, outmap.shape[1] - 40):
            o = outmap[i, j]
            crop = orientation[i - 4:i + 4, j - 4:j + 4]
            crop = crop.reshape(-1)
            crop = list(crop)
            if np.abs(o - 1) < thr:
                sings.append([i, j, 1, np.abs(o - 1)] + crop)
            elif np.abs(o - 0.5) < thr:
                sings.append([i, j, 2, np.abs(o - 0.5)] + crop)
            elif np.abs(o + 0.5) < thr:
                sings.append([i, j, 3, np.abs(o + 0.5)] + crop)
    sings = np.array(sings)

    # remove repeated points and points on the edge

    sings = remove_repeated(sings, r=20)
    # sings = remove_onedge(sings, mask)

    return sings


print("process finger photo...")
fphoto_enh, fphoto_ori, fphoto_mask = fingerphoto_enhance(fphoto, fullreturn=True)





# fphoto_mask = morph.remove_small_holes(fphoto_mask, area_threshold=250)
# fphoto_mask = morph.remove_small_objects(fphoto_mask, min_size=300)
print("process finger print...")
fprint_enh, fprint_ori, fprint_mask = fingerprint_enhance(fprint, fullreturn=True)
fph_sings = poincare(fphoto_ori, fphoto_mask, w_sz=3, thr=0.1)
fpr_sings = poincare(fprint_ori, fprint_mask, w_sz=3, thr=0.1)


np.savez('data.npz', fpr_img=fprint, fph_img=fphoto, fpr_mask = fprint_mask, fph_mask=fphoto_mask, fpr_ori=fprint_ori, fph_ori=fphoto_ori)
exit()


# print(time.time()-t0)
# exit()

def norm01(x):
    x1 = x - x.min()
    x1 = x1 / x1.max()
    # print(x1.min(), x1.max())

    return x1


# cv2.imwrite('./output/fpr_ori.png', (255 * norm01(fphoto_ori)))
# cv2.imwrite('./output/fph_ori.png', (255 * norm01(fprint_ori)))
offset = fprint_ori.shape[1]
outimg = np.concatenate((fprint_ori, fphoto_ori), 1)


n_fpr = fpr_sings.shape[0]
n_fph = fph_sings.shape[0]

# find the match
match = np.zeros([n_fpr, n_fph])
for i in range(n_fpr):
    li = []
    for j in range(n_fph):
        v1 = fpr_sings[i, 3:]
        v2 = fph_sings[j, 3:]
        d = (fpr_sings[i, 3:] - fph_sings[j, 3:]) ** 2
        d = d.mean()
        match[i, j] = d
connect = np.argmin(match, axis=1)
# exit()


plt.imshow(outimg)
plt.scatter(fpr_sings[:, 1], fpr_sings[:, 0], marker='x', c='r')
plt.scatter(fph_sings[:, 1] + offset, fph_sings[:, 0], marker='+', c='r')
for i in range(n_fpr):
    plt.plot([fpr_sings[i, 1], fph_sings[connect[i], 1]+offset], [fpr_sings[i, 0], fph_sings[connect[i], 0]], '-r')
plt.show()

exit()
plt.subplot(2, 2, 1)
plt.imshow(fprint, cmap='gray')

plt.subplot(2, 2, 3)
plt.imshow(fprint_ori)
plt.scatter(fpr_sings[:, 1], fpr_sings[:, 0], marker='x', c='r')

plt.subplot(2, 2, 2)
plt.imshow(fphoto, cmap='gray')

plt.subplot(2, 2, 4)
plt.imshow(fphoto_ori)
plt.scatter(fph_sings[:, 1], fph_sings[:, 0], marker='x', c='r')
plt.show()
