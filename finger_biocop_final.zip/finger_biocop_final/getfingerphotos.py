import os
from os.path import isfile, join
import random
import cv2
import numpy as np
import matplotlib.pyplot as plt
from src.image_enhance import fingerphoto_enhance

random.seed(5)


def showlist(imgs):
    plt.figure(figsize=(10, 8))
    for i in range(len(imgs)):
        plt.subplot(1, len(imgs), i + 1)
        plt.imshow(imgs[i])
    plt.show()


def resize_img(img, w=800):
    rows, cols = np.shape(img)
    aspect_ratio = np.double(rows) / np.double(cols)

    new_rows = w
    new_cols = new_rows / aspect_ratio

    img = cv2.resize(img, (np.int(new_cols), np.int(new_rows)))
    return img


root_dir = '/media/aldb2/M2/datasets/fingerprint/mantech3d/'

class_list = [f.name for f in os.scandir(root_dir) if f.is_dir()]

ad_list = []
for c in class_list:
    sessions = [f.name for f in os.scandir(root_dir + c) if f.is_dir()]
    for s in sessions:
        address = root_dir + c + '/' + s + '/raw/'
        files = [f for f in os.listdir(address) if isfile(join(address, f))]
        for f in files:
            if f[-5] == '0':
                ad_list.append(address + '/' + f)

random.shuffle(ad_list)

core_l = []
delta_l = []
wrong_l = []
coords = []
for ai in range(3, len(ad_list)):
    add = ad_list[ai]
    print(ai, add)
    fphoto = cv2.imread(add)
    if (len(fphoto.shape) > 2):
        fphoto = cv2.cvtColor(fphoto, cv2.COLOR_BGR2GRAY)
    w, h = fphoto.shape
    fphoto = resize_img(fphoto)
    # rotate the image
    angle90 = 90
    center = (w / 2, h / 2)
    fphoto = cv2.rotate(fphoto, cv2.ROTATE_90_CLOCKWISE)
    # hist eq
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(32, 32))
    fphoto = clahe.apply(fphoto)

    a = fingerphoto_enhance(fphoto, fullreturn=True, filter=False)
    if a != -1:
        fphoto_ori = a[0]
        fphoto_mask = a[1]
        fphoto_img = a[2]

        fig = plt.figure(figsize=(15, 12))
        plt.subplot(1, 2, 1)
        plt.imshow(fphoto_img)
        plt.subplot(1, 2, 2)
        plt.imshow(fphoto_ori)




        def onclick(event):
            global ix, iy
            ix, iy = event.xdata, event.ydata
            print('x = %d, y = %d' % (
                ix, iy))

            global coords
            coords.append((ix, iy, event.button))

            plt.subplot(1, 2, 1)
            if event.button == 1:
                plt.scatter(ix, iy, c='r', marker='^')
            elif event.button == 2:
                plt.scatter(ix, iy, c='r', marker='v')
            else:
                plt.scatter(ix, iy, c='r', marker='x')
            plt.subplot(1, 2, 2)
            if event.button == 1:
                plt.scatter(ix, iy, c='r', marker='^')
            elif event.button == 2:
                plt.scatter(ix, iy, c='r', marker='v')
            else:
                plt.scatter(ix, iy, c='r', marker='x')

            fig.canvas.draw()

            # if len(coords) == 2:
            #     fig.canvas.mpl_disconnect(cid)

            return coords


        cid = fig.canvas.mpl_connect('button_press_event', onclick)

        plt.show()
        w = 16
        for bi in range(len(coords)):
            b = coords[bi]
            y = int(b[0])
            x = int(b[1])
            ori = fphoto_ori[x-w:x+w, y-w:y+w]
            # plt.imshow(ori)
            # plt.show()
            if b[2] == 1:
                core_l.append([b[0], b[1], ori.reshape(-1)])
                np.save('./template/core/' + add[-33:-5]+str(bi), core_l)
            elif b[2] == 2:
                delta_l.append([b[0], b[1], ori.reshape(-1)])
                np.save('./template/delta/' + add[-33:-5]+str(bi), core_l)
            else:
                wrong_l.append([b[0], b[1], ori.reshape(-1)])
                np.save('./template/wrong/' + add[-33:-5]+str(bi), core_l)
        coords = []
        # np.savez('coords.npz', core=np.array(core_l), delta = np.array(delta_l), wrong = np.array(wrong_l))

exit()
